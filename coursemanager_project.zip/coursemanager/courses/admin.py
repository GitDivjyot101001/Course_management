from django.contrib import admin
from .models import Student, Semester, CourseCategory, Course, Enrollment

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('user', 'student_id', 'department', 'year_of_study')
    search_fields = ('user__username', 'user__email', 'student_id', 'department')
    list_filter = ('department', 'year_of_study')

@admin.register(Semester)
class SemesterAdmin(admin.ModelAdmin):
    list_display = ('name', 'start_date', 'end_date', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)

@admin.register(CourseCategory)
class CourseCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('code', 'title', 'credits', 'category', 'get_prerequisites_count')
    list_filter = ('category', 'credits')
    search_fields = ('code', 'title', 'description')
    filter_horizontal = ('prerequisites',)
    readonly_fields = ('get_prerequisite_list',)
    
    def get_prerequisites_count(self, obj):
        return obj.prerequisites.count()
    get_prerequisites_count.short_description = 'Prereqs'
    
    def get_prerequisite_list(self, obj):
        if not obj.prerequisites.exists():
            return "No prerequisites required"
        prereq_list = ", ".join([f"{p.code}: {p.title}" for p in obj.prerequisites.all()])
        return prereq_list
    get_prerequisite_list.short_description = 'Prerequisites'
    
    fieldsets = (
        ('Course Information', {
            'fields': ('code', 'title', 'description', 'credits')
        }),
        ('Category & Prerequisites', {
            'fields': ('category', 'prerequisites', 'get_prerequisite_list'),
            'description': (
                'Note: SEC and VAC courses can only be taken once by each student. '
                'Students must complete all prerequisites before enrolling.'
            )
        }),
    )

@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('student', 'course', 'course_category', 'semester', 'status', 'enrollment_date', 'grade')
    list_filter = ('status', 'semester', 'course__category')
    search_fields = ('student__user__username', 'student__student_id', 'course__code', 'course__title')
    date_hierarchy = 'enrollment_date'
    readonly_fields = ('course_prerequisites', 'enrollment_date')
    
    def course_category(self, obj):
        return obj.course.category.get_name_display()
    course_category.short_description = 'Category'
    
    def course_prerequisites(self, obj):
        prereqs = obj.course.prerequisites.all()
        if not prereqs:
            return "No prerequisites required"
        return ", ".join([f"{p.code}: {p.title}" for p in prereqs])
    course_prerequisites.short_description = 'Course Prerequisites'
    
    fieldsets = (
        ('Enrollment Information', {
            'fields': ('student', 'course', 'semester', 'status', 'grade', 'enrollment_date')
        }),
        ('Course Requirements', {
            'fields': ('course_prerequisites',),
            'description': (
                'Validation rules enforced:<br>'
                '1. Students cannot take the same SEC/VAC course twice<br>'
                '2. Students must complete all prerequisites before enrolling in a course'
            ),
            'classes': ('collapse',),
        }),
    )
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "semester":
            # Default to active semesters
            kwargs["queryset"] = Semester.objects.filter(is_active=True)
        return super().formfield_for_foreignkey(db_field, request, **kwargs)
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as e:
            self.message_user(request, f"Error saving enrollment: {str(e)}", level='error')
