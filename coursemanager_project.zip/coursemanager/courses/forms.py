from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from .models import Student, Course, Enrollment, Semester


class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'password1', 'password2']


class StudentProfileForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['student_id', 'department', 'year_of_study']
        widgets = {
            'student_id': forms.TextInput(attrs={'class': 'form-control'}),
            'department': forms.TextInput(attrs={'class': 'form-control'}),
            'year_of_study': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'max': 10}),
        }


class CourseEnrollmentForm(forms.ModelForm):
    class Meta:
        model = Enrollment
        fields = ['course', 'semester']
        widgets = {
            'course': forms.Select(attrs={'class': 'form-control'}),
            'semester': forms.Select(attrs={'class': 'form-control'}),
        }
    
    def __init__(self, *args, **kwargs):
        self.student = kwargs.pop('student', None)
        super().__init__(*args, **kwargs)
        
        # Only show active semesters
        self.fields['semester'].queryset = Semester.objects.filter(is_active=True)
        
        if self.student:
            # Get the student's completed courses and currently enrolled courses
            completed_courses = Enrollment.objects.filter(
                student=self.student, 
                status='completed'
            ).values_list('course_id', flat=True)
            
            enrolled_course_ids = Enrollment.objects.filter(
                student=self.student
            ).values_list('course_id', flat=True)
            
            # For each course, check if prerequisites are satisfied and SEC/VAC rules are met
            available_courses = []
            all_courses = Course.objects.all()
            
            for course in all_courses:
                # Skip if already enrolled
                if course.id in enrolled_course_ids:
                    continue
                
                # Check for SEC/VAC duplicates
                if course.category.name in ['SEC', 'VAC']:
                    # Check if this student has already enrolled in this course before (any status)
                    existing_enrollments = Enrollment.objects.filter(
                        student=self.student,
                        course=course
                    )
                    
                    if existing_enrollments.exists():
                        # Skip this course as it violates SEC/VAC rules
                        continue
                
                # Check prerequisites
                prerequisites = course.prerequisites.all()
                prereqs_satisfied = True
                
                for prereq in prerequisites:
                    if prereq.id not in completed_courses:
                        prereqs_satisfied = False
                        break
                
                if prereqs_satisfied:
                    available_courses.append(course.id)
            
            # Filter the course queryset to only show available courses
            self.fields['course'].queryset = Course.objects.filter(
                id__in=available_courses
            )
            
            # Add custom help_text with explanations
            self.fields['course'].help_text = (
                "Only courses you are eligible for are shown. "
                "Courses may be hidden if you've already taken them (for SEC/VAC) "
                "or if you don't meet prerequisites."
            )
    
    def clean(self):
        cleaned_data = super().clean()
        course = cleaned_data.get('course')
        semester = cleaned_data.get('semester')
        
        if not self.student or not course:
            return cleaned_data
            
        # Check duplicate enrollment in the same semester
        if semester and Enrollment.objects.filter(
            student=self.student,
            course=course,
            semester=semester
        ).exists():
            raise ValidationError(
                "You are already enrolled in this course for the selected semester."
            )
        
        # Check SEC/VAC rule (double check)
        if course.category.name in ['SEC', 'VAC']:
            existing_enrollments = Enrollment.objects.filter(
                student=self.student,
                course=course
            )
            
            if existing_enrollments.exists():
                raise ValidationError(
                    f"You cannot enroll in the same {course.category.get_name_display()} course twice."
                )
        
        # Check prerequisites
        prerequisites = course.prerequisites.all()
        if prerequisites:
            completed_courses = set(
                Enrollment.objects.filter(
                    student=self.student,
                    status='completed'
                ).values_list('course_id', flat=True)
            )
            
            missing_prerequisites = []
            for prereq in prerequisites:
                if prereq.id not in completed_courses:
                    missing_prerequisites.append(f"{prereq.code}: {prereq.title}")
            
            if missing_prerequisites:
                raise ValidationError(
                    f"Missing prerequisites: {', '.join(missing_prerequisites)}"
                )
        
        return cleaned_data
