import datetime
import random
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from courses.models import Student, Semester, CourseCategory, Course, Enrollment


class Command(BaseCommand):
    help = 'Populates the database with minimal test data for development'

    def handle(self, *args, **kwargs):
        self.stdout.write('Creating minimal test data...')
        
        # Clear existing data
        self.stdout.write('Clearing existing data...')
        Enrollment.objects.all().delete()
        Course.objects.all().delete()
        CourseCategory.objects.all().delete()
        Semester.objects.all().delete()
        Student.objects.all().delete()
        # Don't delete admin user
        User.objects.filter(is_superuser=False).delete()
        
        # Create semesters
        self.stdout.write('Creating semesters...')
        fall_2023 = Semester.objects.create(
            name='Fall 2023',
            start_date=datetime.date(2023, 9, 1),
            end_date=datetime.date(2023, 12, 15),
            is_active=False
        )
        spring_2024 = Semester.objects.create(
            name='Spring 2024',
            start_date=datetime.date(2024, 1, 15),
            end_date=datetime.date(2024, 5, 15),
            is_active=False
        )
        current_semester = Semester.objects.create(
            name='Fall 2024',
            start_date=datetime.date(2024, 9, 1),
            end_date=datetime.date(2024, 12, 15),
            is_active=True
        )
        
        # Create course categories
        self.stdout.write('Creating course categories...')
        ge_category = CourseCategory.objects.create(
            name='GE',
            description='General Education courses that provide a broad foundation across disciplines.'
        )
        sec_category = CourseCategory.objects.create(
            name='SEC',
            description='Skill Enhancement Courses designed to develop specific technical or professional skills.'
        )
        vac_category = CourseCategory.objects.create(
            name='VAC',
            description='Value Added Courses focused on personal development and soft skills.'
        )
        
        # Create test users and students
        self.stdout.write('Creating test users and students...')
        test_users = []
        for i in range(1, 6):
            username = f'student{i}'
            user = User.objects.create_user(
                username=username,
                email=f'{username}@example.com',
                password='password123',
                first_name=f'Student{i}',
                last_name='Test'
            )
            test_users.append(user)
            
            # Create student profile
            Student.objects.create(
                user=user,
                student_id=f'S00{i}',
                department='Computer Science',
                year_of_study=i % 4 + 1
            )
        
        # Create courses
        self.stdout.write('Creating courses...')
        
        # Basic courses (no prerequisites)
        intro_programming = Course.objects.create(
            code='GE101',
            title='Introduction to Programming',
            description='A beginner-friendly course covering programming fundamentals using Python.',
            credits=3,
            category=ge_category
        )
        
        intro_databases = Course.objects.create(
            code='GE102',
            title='Database Fundamentals',
            description='Introduction to database design, SQL, and data management principles.',
            credits=3,
            category=ge_category
        )
        
        web_dev_basics = Course.objects.create(
            code='GE103',
            title='Web Development Fundamentals',
            description='Basics of HTML, CSS, and JavaScript for building interactive websites.',
            credits=3,
            category=ge_category
        )
        
        # SEC courses (with prerequisites)
        advanced_programming = Course.objects.create(
            code='SEC201',
            title='Advanced Programming Concepts',
            description='Object-oriented programming, data structures, and algorithm analysis.',
            credits=4,
            category=sec_category
        )
        advanced_programming.prerequisites.add(intro_programming)
        
        database_design = Course.objects.create(
            code='SEC202',
            title='Advanced Database Design',
            description='Normalization, optimization, and advanced SQL concepts.',
            credits=4,
            category=sec_category
        )
        database_design.prerequisites.add(intro_databases)
        
        # VAC courses
        tech_writing = Course.objects.create(
            code='VAC301',
            title='Technical Writing',
            description='Effective communication of technical information in written form.',
            credits=2,
            category=vac_category
        )
        
        tech_entrepreneurship = Course.objects.create(
            code='VAC302',
            title='Technology Entrepreneurship',
            description='Business principles for tech startups and product development.',
            credits=2,
            category=vac_category
        )
        
        # Create enrollment history
        self.stdout.write('Creating enrollment history...')
        
        # First student (has completed intro courses)
        student1 = Student.objects.get(student_id='S001')
        
        # Completed courses from past semesters
        Enrollment.objects.create(
            student=student1,
            course=intro_programming,
            semester=fall_2023,
            status='completed',
            grade='A'
        )
        
        Enrollment.objects.create(
            student=student1,
            course=intro_databases,
            semester=fall_2023,
            status='completed',
            grade='B'
        )
        
        # Current semester enrollments
        Enrollment.objects.create(
            student=student1,
            course=advanced_programming,
            semester=current_semester,
            status='enrolled'
        )
        
        # Second student (SEC focus)
        student2 = Student.objects.get(student_id='S002')
        
        Enrollment.objects.create(
            student=student2,
            course=intro_programming,
            semester=fall_2023,
            status='completed',
            grade='A'
        )
        
        Enrollment.objects.create(
            student=student2,
            course=advanced_programming,
            semester=spring_2024,
            status='completed',
            grade='B'
        )
        
        Enrollment.objects.create(
            student=student2,
            course=database_design,
            semester=current_semester,
            status='enrolled'
        )
        
        # Demonstration of taking same VAC course twice (should be prevented)
        student3 = Student.objects.get(student_id='S003')
        
        # Create a completed enrollment in the VAC course
        Enrollment.objects.create(
            student=student3,
            course=tech_writing,
            semester=fall_2023,
            status='completed',
            grade='A'
        )
        
        # We'll demonstrate that trying to enroll again should be prevented by validation
        
        # Student 4 (trying courses without prereqs)
        student4 = Student.objects.get(student_id='S004')
        
        # Note: Student has not completed intro_programming, so they shouldn't 
        # be allowed to enroll in advanced_programming
        
        self.stdout.write(self.style.SUCCESS('Minimal test data created successfully!'))