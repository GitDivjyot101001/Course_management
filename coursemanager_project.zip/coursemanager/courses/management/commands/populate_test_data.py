import datetime
import random
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from courses.models import Student, Semester, CourseCategory, Course, Enrollment


class Command(BaseCommand):
    help = 'Populates the database with random test data from Mockaroo'

    def handle(self, *args, **kwargs):
        self.stdout.write('Creating random test data...')
        
        # Clear existing data
        self.stdout.write('Clearing existing data...')
        Enrollment.objects.all().delete()
        Course.objects.all().delete()
        CourseCategory.objects.all().delete()
        Semester.objects.all().delete()
        Student.objects.all().delete()
        # Don't delete admin user
        User.objects.filter(is_superuser=False).delete()
        
        # Create semesters
        self.stdout.write('Creating semesters...')
        fall_2023 = Semester.objects.create(
            name='Fall 2023',
            start_date=datetime.date(2023, 9, 1),
            end_date=datetime.date(2023, 12, 15),
            is_active=False
        )
        spring_2024 = Semester.objects.create(
            name='Spring 2024',
            start_date=datetime.date(2024, 1, 15),
            end_date=datetime.date(2024, 5, 15),
            is_active=False
        )
        current_semester = Semester.objects.create(
            name='Fall 2024',
            start_date=datetime.date(2024, 9, 1),
            end_date=datetime.date(2024, 12, 15),
            is_active=True
        )
        
        # Create course categories
        self.stdout.write('Creating course categories...')
        ge_category = CourseCategory.objects.create(
            name='GE',
            description='General Education courses that provide a broad foundation across disciplines.'
        )
        sec_category = CourseCategory.objects.create(
            name='SEC',
            description='Skill Enhancement Courses designed to develop specific technical or professional skills.'
        )
        vac_category = CourseCategory.objects.create(
            name='VAC',
            description='Value Added Courses focused on personal development and soft skills.'
        )
        
        # Generate random students
        self.stdout.write('Generating random students...')
        
        # Create random users with Mockaroo-like data (we'll simulate the API call)
        departments = ['Computer Science', 'Electrical Engineering', 'Mechanical Engineering', 
                      'Civil Engineering', 'Business Administration', 'Psychology', 'Biology']
        
        # Generate 30 random students
        for i in range(1, 31):
            first_name = f"Student{i}"
            last_name = f"User{i}"
            username = f"student{i}"
            email = f"{username}@example.com"
            
            # Create the user
            user = User.objects.create_user(
                username=username,
                email=email,
                password="password123",
                first_name=first_name,
                last_name=last_name
            )
            
            # Create the student profile
            Student.objects.create(
                user=user,
                student_id=f"S{100+i:03d}",
                department=random.choice(departments),
                year_of_study=random.randint(1, 4)
            )
            
        self.stdout.write('Students created successfully!')
        
        # Generate random courses
        self.stdout.write('Generating random courses...')
        
        # GE courses (no prerequisites)
        ge_course_data = [
            {'code': 'GE101', 'title': 'Introduction to Critical Thinking', 'credits': 3},
            {'code': 'GE102', 'title': 'College Mathematics', 'credits': 3},
            {'code': 'GE103', 'title': 'Environmental Science', 'credits': 3},
            {'code': 'GE104', 'title': 'World History', 'credits': 3},
            {'code': 'GE105', 'title': 'Introduction to Psychology', 'credits': 3},
            {'code': 'GE106', 'title': 'Fundamentals of Communication', 'credits': 3},
            {'code': 'GE107', 'title': 'Introduction to Literature', 'credits': 3},
            {'code': 'GE108', 'title': 'Introduction to Philosophy', 'credits': 3},
            {'code': 'GE109', 'title': 'Microeconomics', 'credits': 3},
            {'code': 'GE110', 'title': 'Introduction to Sociology', 'credits': 3},
        ]
        
        ge_courses = []
        for course_data in ge_course_data:
            course = Course.objects.create(
                code=course_data['code'],
                title=course_data['title'],
                description=f"A general education course on {course_data['title'].lower()}.",
                credits=course_data['credits'],
                category=ge_category
            )
            ge_courses.append(course)
        
        # SEC courses (some have prerequisites)
        sec_course_data = [
            {'code': 'SEC201', 'title': 'Web Development', 'credits': 4, 'prereqs': [0, 1]},
            {'code': 'SEC202', 'title': 'Database Management', 'credits': 4, 'prereqs': [2]},
            {'code': 'SEC203', 'title': 'Data Analysis', 'credits': 4, 'prereqs': [1, 2]},
            {'code': 'SEC204', 'title': 'Programming with Python', 'credits': 4, 'prereqs': []},
            {'code': 'SEC205', 'title': 'Mobile App Development', 'credits': 4, 'prereqs': [0, 3]},
            {'code': 'SEC206', 'title': 'Network Security', 'credits': 4, 'prereqs': [2, 4]},
            {'code': 'SEC207', 'title': 'Cloud Computing', 'credits': 4, 'prereqs': [1]},
            {'code': 'SEC208', 'title': 'Machine Learning Fundamentals', 'credits': 4, 'prereqs': [2, 3]},
        ]
        
        sec_courses = []
        for course_data in sec_course_data:
            course = Course.objects.create(
                code=course_data['code'],
                title=course_data['title'],
                description=f"A skill enhancement course on {course_data['title'].lower()}.",
                credits=course_data['credits'],
                category=sec_category
            )
            # Add prerequisites
            for prereq_idx in course_data.get('prereqs', []):
                if prereq_idx < len(ge_courses):
                    course.prerequisites.add(ge_courses[prereq_idx])
            sec_courses.append(course)
        
        # VAC courses (some have prerequisites)
        vac_course_data = [
            {'code': 'VAC301', 'title': 'Leadership Skills', 'credits': 2, 'prereqs': []},
            {'code': 'VAC302', 'title': 'Technical Writing', 'credits': 2, 'prereqs': []},
            {'code': 'VAC303', 'title': 'Professional Ethics', 'credits': 2, 'prereqs': []},
            {'code': 'VAC304', 'title': 'Project Management', 'credits': 2, 'prereqs': [0, 1]},
            {'code': 'VAC305', 'title': 'Entrepreneurship', 'credits': 2, 'prereqs': []},
            {'code': 'VAC306', 'title': 'Digital Marketing', 'credits': 2, 'prereqs': [2]},
        ]
        
        vac_courses = []
        for course_data in vac_course_data:
            course = Course.objects.create(
                code=course_data['code'],
                title=course_data['title'],
                description=f"A value added course on {course_data['title'].lower()}.",
                credits=course_data['credits'],
                category=vac_category
            )
            # Add prerequisites
            for prereq_idx in course_data.get('prereqs', []):
                if prereq_idx < len(sec_courses):
                    course.prerequisites.add(sec_courses[prereq_idx])
            vac_courses.append(course)
        
        # Create enrollments with random data
        self.stdout.write('Creating random enrollments...')
        
        # Get all students
        students = list(Student.objects.all())
        all_courses = ge_courses + sec_courses + vac_courses
        
        # Generate random enrollments
        grades = ['A', 'B', 'C', 'D', 'F']
        statuses = ['enrolled', 'completed', 'dropped']
        
        # For each student, create some enrollment history
        for student in students:
            # Decide how many courses this student has taken
            num_completed = random.randint(1, 8)
            num_current = random.randint(1, 4)
            
            # Sample courses without replacement to avoid duplicate enrollments
            sampled_courses = random.sample(all_courses, min(num_completed + num_current, len(all_courses)))
            
            # Past courses (completed)
            for i in range(min(num_completed, len(sampled_courses))):
                course = sampled_courses[i]
                past_semester = random.choice([fall_2023, spring_2024])
                grade = random.choice(grades)
                
                Enrollment.objects.create(
                    student=student,
                    course=course,
                    semester=past_semester,
                    status='completed',
                    grade=grade
                )
            
            # Current courses
            for i in range(num_completed, min(num_completed + num_current, len(sampled_courses))):
                course = sampled_courses[i]
                status = random.choices(['enrolled', 'dropped'], weights=[0.9, 0.1])[0]
                
                Enrollment.objects.create(
                    student=student,
                    course=course,
                    semester=current_semester,
                    status=status,
                    grade=None
                )
        
        self.stdout.write(self.style.SUCCESS('Random test data created successfully!'))