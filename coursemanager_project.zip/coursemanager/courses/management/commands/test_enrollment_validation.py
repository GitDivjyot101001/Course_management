from django.core.management.base import BaseCommand
from django.core.exceptions import ValidationError
from courses.models import Student, Course, Enrollment, Semester


class Command(BaseCommand):
    help = 'Tests the enrollment validation rules'

    def handle(self, *args, **kwargs):
        self.stdout.write('Testing enrollment validation rules...')
        
        # Test duplicate VAC course enrollment
        self.test_vac_duplicate_enrollment()
        
        # Test prerequisite validation
        self.test_prerequisite_validation()
    
    def test_vac_duplicate_enrollment(self):
        """Test that a student cannot enroll in the same VAC course twice."""
        self.stdout.write('\n1. Testing VAC duplicate enrollment prevention:')
        
        try:
            student = Student.objects.get(student_id='S003')
            tech_writing = Course.objects.get(code='VAC301')
            current_semester = Semester.objects.get(is_active=True)
            
            self.stdout.write(f'  - Attempting to enroll {student.user.username} in {tech_writing.code} (a VAC course) again...')
            
            # Check if the student is already enrolled in this course
            existing_enrollment = Enrollment.objects.filter(
                student=student,
                course=tech_writing
            ).exists()
            
            if existing_enrollment:
                self.stdout.write(f'  - Student already has an enrollment record for {tech_writing.code}')
            
            # Try to create a new enrollment (this should fail)
            try:
                enrollment = Enrollment(
                    student=student,
                    course=tech_writing,
                    semester=current_semester,
                    status='enrolled'
                )
                enrollment.save()
                self.stdout.write(self.style.ERROR('  - ❌ TEST FAILED: Duplicate VAC enrollment was allowed!'))
            except ValidationError as e:
                self.stdout.write(self.style.SUCCESS(f'  - ✅ TEST PASSED: ValidationError raised: {e}'))
                self.stdout.write('  - This is correct behavior - preventing duplicate VAC enrollment.')
        
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'  - Error during test: {e}'))
    
    def test_prerequisite_validation(self):
        """Test that a student cannot enroll in a course without completing prerequisites."""
        self.stdout.write('\n2. Testing prerequisite validation:')
        
        try:
            student4 = Student.objects.get(student_id='S004')
            advanced_programming = Course.objects.get(code='SEC201')
            current_semester = Semester.objects.get(is_active=True)
            
            self.stdout.write(f'  - Attempting to enroll {student4.user.username} in {advanced_programming.code} without prerequisites...')
            
            # List the prerequisites for this course
            prerequisites = advanced_programming.prerequisites.all()
            self.stdout.write(f'  - Course has {prerequisites.count()} prerequisites:')
            for prereq in prerequisites:
                self.stdout.write(f'    * {prereq.code}: {prereq.title}')
            
            # Check if student has completed the prerequisites
            completed_courses = Enrollment.objects.filter(
                student=student4,
                status='completed'
            ).values_list('course_id', flat=True)
            
            missing_prereqs = []
            for prereq in prerequisites:
                if prereq.id not in completed_courses:
                    missing_prereqs.append(prereq)
            
            if missing_prereqs:
                self.stdout.write(f'  - Student is missing {len(missing_prereqs)} prerequisites')
            
            # Try to create a new enrollment (this should fail)
            try:
                enrollment = Enrollment(
                    student=student4,
                    course=advanced_programming,
                    semester=current_semester,
                    status='enrolled'
                )
                enrollment.save()
                self.stdout.write(self.style.ERROR('  - ❌ TEST FAILED: Enrollment without prerequisites was allowed!'))
            except ValidationError as e:
                self.stdout.write(self.style.SUCCESS(f'  - ✅ TEST PASSED: ValidationError raised: {e}'))
                self.stdout.write('  - This is correct behavior - preventing enrollment without prerequisites.')
        
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'  - Error during test: {e}'))