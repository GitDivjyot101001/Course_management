from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError


class Student(models.Model):
    """Model representing a student user profile."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student_profile')
    student_id = models.CharField(max_length=20, unique=True)
    department = models.CharField(max_length=100)
    year_of_study = models.PositiveIntegerField()
    
    def __str__(self):
        return f"{self.user.username} - {self.student_id}"


class Semester(models.Model):
    """Model representing an academic semester."""
    name = models.CharField(max_length=50)  # e.g., "Fall 2023"
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=False)
    
    def __str__(self):
        return self.name


class CourseCategory(models.Model):
    """Model representing course categories (GE, SEC, VAC)."""
    CATEGORY_CHOICES = [
        ('GE', 'General Elective'),
        ('SEC', 'Skill Enhancement Course'),
        ('VAC', 'Value Added Course'),
    ]
    
    name = models.CharField(max_length=3, choices=CATEGORY_CHOICES)
    description = models.TextField()
    
    def __str__(self):
        return self.get_name_display()
    
    class Meta:
        verbose_name_plural = "Course Categories"


class Course(models.Model):
    """Model representing an academic course."""
    code = models.CharField(max_length=20, unique=True)
    title = models.CharField(max_length=200)
    description = models.TextField()
    credits = models.PositiveIntegerField()
    category = models.ForeignKey(CourseCategory, on_delete=models.CASCADE, related_name='courses')
    prerequisites = models.ManyToManyField('self', symmetrical=False, blank=True)
    
    def __str__(self):
        return f"{self.code}: {self.title} ({self.category.name})"


class Enrollment(models.Model):
    """Model representing student enrollment in a course for a specific semester."""
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='enrollments')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enrollments')
    semester = models.ForeignKey(Semester, on_delete=models.CASCADE, related_name='enrollments')
    enrollment_date = models.DateTimeField(auto_now_add=True)
    
    STATUS_CHOICES = [
        ('enrolled', 'Enrolled'),
        ('completed', 'Completed'),
        ('dropped', 'Dropped'),
    ]
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='enrolled')
    grade = models.CharField(max_length=2, blank=True, null=True)
    
    class Meta:
        unique_together = ['student', 'course', 'semester']
    
    def __str__(self):
        return f"{self.student.user.username} - {self.course.code} ({self.semester.name})"
    
    def save(self, *args, **kwargs):
        """Validate prerequisites and prevent duplicate enrollments before saving."""
        # Check if the student has already completed or is currently enrolled in this course
        # for SEC and VAC courses (they shouldn't take the same SEC/VAC course twice)
        if self.course.category.name in ['SEC', 'VAC']:
            # Check if this student has already enrolled in this course before
            existing_enrollments = Enrollment.objects.filter(
                student=self.student,
                course=self.course
            ).exclude(pk=self.pk if self.pk else None)
            
            if existing_enrollments.exists():
                raise ValidationError(
                    f"Student cannot enroll in the same {self.course.category.get_name_display()} course twice."
                )
        
        # Check prerequisites for all new enrollments
        if not self.pk:  # Only check prerequisites for new enrollments
            # Get all courses this student has successfully completed
            completed_courses = Enrollment.objects.filter(
                student=self.student,
                status='completed'
            ).values_list('course_id', flat=True)
            
            # Check if all prerequisites are completed
            prerequisites = self.course.prerequisites.all()
            missing_prerequisites = []
            
            for prereq in prerequisites:
                if prereq.id not in completed_courses:
                    missing_prerequisites.append(prereq)
            
            if missing_prerequisites:
                prerequisite_titles = ', '.join([p.title for p in missing_prerequisites])
                raise ValidationError(
                    f"Missing prerequisites for {self.course.title}: {prerequisite_titles}"
                )
        
        super().save(*args, **kwargs)
