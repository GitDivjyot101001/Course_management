from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Student, Semester, CourseCategory, Course, Enrollment


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']
        read_only_fields = ['id']


class StudentSerializer(serializers.ModelSerializer):
    user = UserSerializer()
    
    class Meta:
        model = Student
        fields = ['id', 'user', 'student_id', 'department', 'year_of_study']
        read_only_fields = ['id']
    
    def create(self, validated_data):
        user_data = validated_data.pop('user')
        user = User.objects.create_user(**user_data)
        student = Student.objects.create(user=user, **validated_data)
        return student
    
    def update(self, instance, validated_data):
        user_data = validated_data.pop('user', {})
        if user_data:
            user = instance.user
            for key, value in user_data.items():
                setattr(user, key, value)
            user.save()
        
        for key, value in validated_data.items():
            setattr(instance, key, value)
        instance.save()
        return instance


class SemesterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Semester
        fields = ['id', 'name', 'start_date', 'end_date', 'is_active']
        read_only_fields = ['id']


class CourseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseCategory
        fields = ['id', 'name', 'description']
        read_only_fields = ['id']


class CourseSerializer(serializers.ModelSerializer):
    category_display = serializers.CharField(source='category.get_name_display', read_only=True)
    prerequisites = serializers.PrimaryKeyRelatedField(
        queryset=Course.objects.all(),
        many=True,
        required=False
    )
    
    class Meta:
        model = Course
        fields = ['id', 'code', 'title', 'description', 'credits', 'category', 
                  'category_display', 'prerequisites']
        read_only_fields = ['id']


class CourseDetailSerializer(CourseSerializer):
    prerequisites = CourseSerializer(many=True, read_only=True)
    category = CourseCategorySerializer(read_only=True)


class EnrollmentSerializer(serializers.ModelSerializer):
    course_code = serializers.CharField(source='course.code', read_only=True)
    course_title = serializers.CharField(source='course.title', read_only=True)
    semester_name = serializers.CharField(source='semester.name', read_only=True)
    category = serializers.CharField(source='course.category.name', read_only=True)
    
    class Meta:
        model = Enrollment
        fields = ['id', 'student', 'course', 'course_code', 'course_title', 
                  'semester', 'semester_name', 'enrollment_date', 'status', 
                  'grade', 'category']
        read_only_fields = ['id', 'enrollment_date', 'course_code', 'course_title', 
                           'semester_name', 'category']
    
    def validate(self, data):
        student = data.get('student')
        course = data.get('course')
        semester = data.get('semester')
        
        # Check if student is already enrolled in this course in any semester
        if Enrollment.objects.filter(student=student, course=course).exists():
            raise serializers.ValidationError(
                "Student has already completed or is currently enrolled in this course."
            )
        
        # Check prerequisites
        prerequisites = course.prerequisites.all()
        if prerequisites:
            completed_courses = set(
                Enrollment.objects.filter(
                    student=student, 
                    status='completed'
                ).values_list('course_id', flat=True)
            )
            
            missing_prerequisites = []
            for prereq in prerequisites:
                if prereq.id not in completed_courses:
                    missing_prerequisites.append(f"{prereq.code}: {prereq.title}")
            
            if missing_prerequisites:
                raise serializers.ValidationError(
                    f"Missing prerequisites: {', '.join(missing_prerequisites)}"
                )
        
        return data
