document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Add Bootstrap classes to Django form elements if not already added
    const djangoFormControls = document.querySelectorAll('input, select, textarea');
    djangoFormControls.forEach(function(element) {
        if (element.type !== 'submit' && element.type !== 'button' && element.type !== 'hidden') {
            if (!element.classList.contains('form-control') && !element.classList.contains('form-select') && !element.classList.contains('form-check-input')) {
                if (element.tagName === 'SELECT') {
                    element.classList.add('form-select');
                } else if (element.type === 'checkbox' || element.type === 'radio') {
                    element.classList.add('form-check-input');
                } else {
                    element.classList.add('form-control');
                }
            }
        }
    });

    // Course details page: Toggle prerequisites details
    const togglePrerequisites = document.getElementById('toggle-prerequisites');
    if (togglePrerequisites) {
        togglePrerequisites.addEventListener('click', function(e) {
            e.preventDefault();
            const prerequisitesList = document.getElementById('prerequisites-list');
            if (prerequisitesList) {
                prerequisitesList.classList.toggle('d-none');
                if (prerequisitesList.classList.contains('d-none')) {
                    togglePrerequisites.textContent = 'Show Prerequisites';
                } else {
                    togglePrerequisites.textContent = 'Hide Prerequisites';
                }
            }
        });
    }

    // Handle enrollment form course selection
    const courseSelect = document.getElementById('id_course');
    if (courseSelect) {
        // If a course ID is provided in the URL, select that course
        const urlParams = new URLSearchParams(window.location.search);
        const courseId = urlParams.get('course');
        if (courseId) {
            for (let i = 0; i < courseSelect.options.length; i++) {
                if (courseSelect.options[i].value === courseId) {
                    courseSelect.selectedIndex = i;
                    break;
                }
            }
        }
    }

    // Course list page: Category filter change handler
    const categoryFilter = document.getElementById('category');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', function() {
            // If there's a search query, preserve it
            const currentSearch = document.getElementById('search').value;
            if (currentSearch) {
                document.getElementById('search').value = currentSearch;
            }
        });
    }

    // Enrollment history page: Add semester toggle functionality
    const semesterToggles = document.querySelectorAll('.semester-toggle');
    semesterToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('data-target');
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.classList.toggle('d-none');
                const icon = this.querySelector('i');
                if (icon) {
                    icon.classList.toggle('fa-chevron-down');
                    icon.classList.toggle('fa-chevron-up');
                }
            }
        });
    });
});
