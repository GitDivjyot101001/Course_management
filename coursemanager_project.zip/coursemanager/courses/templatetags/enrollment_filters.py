from django import template
from courses.models import Enrollment

register = template.Library()

@register.filter(name='sum_credits')
def sum_credits(enrollments):
    """Calculate the total credits for a list of enrollments."""
    total_credits = 0
    for enrollment in enrollments:
        total_credits += enrollment.course.credits
    return total_credits

@register.filter(name='completed_count')
def completed_count(enrollments):
    """Count the number of completed enrollments."""
    return sum(1 for enrollment in enrollments if enrollment.status == 'completed')