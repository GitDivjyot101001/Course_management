from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User
from .models import Student, Course, CourseCategory, Semester, Enrollment


class ModelsTestCase(TestCase):
    def setUp(self):
        # Create a test user
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword'
        )
        
        # Create a student
        self.student = Student.objects.create(
            user=self.user,
            student_id='S12345',
            department='Computer Science',
            year_of_study=2
        )
        
        # Create course categories
        self.ge_category = CourseCategory.objects.create(
            name='GE',
            description='General Elective Courses'
        )
        
        self.sec_category = CourseCategory.objects.create(
            name='SEC',
            description='Skill Enhancement Courses'
        )
        
        # Create courses
        self.course1 = Course.objects.create(
            code='CS101',
            title='Introduction to Programming',
            description='Basic programming concepts',
            credits=3,
            category=self.ge_category
        )
        
        self.course2 = Course.objects.create(
            code='CS201',
            title='Data Structures',
            description='Advanced data structures',
            credits=4,
            category=self.ge_category
        )
        
        # Add course1 as a prerequisite for course2
        self.course2.prerequisites.add(self.course1)
        
        # Create a semester
        self.semester = Semester.objects.create(
            name='Fall 2023',
            start_date='2023-08-01',
            end_date='2023-12-31',
            is_active=True
        )
    
    def test_student_creation(self):
        self.assertEqual(self.student.user.username, 'testuser')
        self.assertEqual(self.student.student_id, 'S12345')
    
    def test_course_prerequisites(self):
        self.assertEqual(self.course2.prerequisites.count(), 1)
        self.assertEqual(self.course2.prerequisites.first(), self.course1)
    
    def test_enrollment_creation(self):
        enrollment = Enrollment.objects.create(
            student=self.student,
            course=self.course1,
            semester=self.semester,
            status='enrolled'
        )
        
        self.assertEqual(enrollment.student, self.student)
        self.assertEqual(enrollment.course, self.course1)
        self.assertEqual(enrollment.status, 'enrolled')


class ViewsTestCase(TestCase):
    def setUp(self):
        # Create a test user
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpassword'
        )
        
        # Create a student
        self.student = Student.objects.create(
            user=self.user,
            student_id='S12345',
            department='Computer Science',
            year_of_study=2
        )
        
        # Create course category
        self.ge_category = CourseCategory.objects.create(
            name='GE',
            description='General Elective Courses'
        )
        
        # Create courses
        self.course = Course.objects.create(
            code='CS101',
            title='Introduction to Programming',
            description='Basic programming concepts',
            credits=3,
            category=self.ge_category
        )
        
        # Create a semester
        self.semester = Semester.objects.create(
            name='Fall 2023',
            start_date='2023-08-01',
            end_date='2023-12-31',
            is_active=True
        )
    
    def test_login_view(self):
        response = self.client.get(reverse('login'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'courses/login.html')
    
    def test_register_view(self):
        response = self.client.get(reverse('register'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'courses/register.html')
    
    def test_dashboard_view_login_required(self):
        response = self.client.get(reverse('dashboard'))
        self.assertNotEqual(response.status_code, 200)
    
    def test_dashboard_view_authenticated(self):
        self.client.login(username='testuser', password='testpassword')
        response = self.client.get(reverse('dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'courses/dashboard.html')
