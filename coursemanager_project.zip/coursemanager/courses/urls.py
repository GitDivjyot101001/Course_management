from django.urls import path, include
from django.contrib.auth import views as auth_views
from rest_framework.routers import DefaultRouter
from . import views

# API router
router = DefaultRouter()
router.register(r'students', views.StudentViewSet)
router.register(r'courses', views.CourseViewSet)
router.register(r'enrollments', views.EnrollmentViewSet, basename='enrollment')
router.register(r'semesters', views.SemesterViewSet)
router.register(r'categories', views.CourseCategoryViewSet)

urlpatterns = [
    # Web routes
    path('', views.login_view, name='index'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('profile/', views.profile_view, name='profile'),
    path('courses/', views.course_list_view, name='courses'),
    path('courses/<int:course_id>/', views.course_detail_view, name='course_detail'),
    path('enrollment/history/', views.enrollment_history_view, name='enrollment_history'),
    path('enrollment/new/', views.enroll_course_view, name='enroll_course'),
    
    # API routes
    path('api/', include(router.urls)),
]
