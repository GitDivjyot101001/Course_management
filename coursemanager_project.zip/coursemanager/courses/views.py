from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate
from django.db.models import Q
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, DetailView, CreateView, UpdateView, TemplateView
from django.urls import reverse_lazy
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from rest_framework import viewsets, permissions, status, filters
from rest_framework.response import Response
from rest_framework.decorators import action

from .models import Student, Course, Enrollment, Semester, CourseCategory
from .forms import UserRegisterForm, StudentProfileForm, CourseEnrollmentForm
from .serializers import (
    UserSerializer, StudentSerializer, CourseSerializer, CourseDetailSerializer,
    EnrollmentSerializer, SemesterSerializer, CourseCategorySerializer
)


# API Views
class UserViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = UserSerializer
    queryset = User.objects.all()


class StudentViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = StudentSerializer
    queryset = Student.objects.all()
    
    @action(detail=False, methods=['get'])
    def me(self, request):
        try:
            student = request.user.student_profile
            serializer = self.get_serializer(student)
            return Response(serializer.data)
        except Student.DoesNotExist:
            return Response(
                {"detail": "Student profile not found for this user."},
                status=status.HTTP_404_NOT_FOUND
            )


class CourseViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    queryset = Course.objects.all()
    filter_backends = [filters.SearchFilter]
    search_fields = ['code', 'title', 'description']
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return CourseDetailSerializer
        return CourseSerializer
    
    @action(detail=False, methods=['get'])
    def available(self, request):
        try:
            student = request.user.student_profile
            # Get courses the student is already enrolled in
            enrolled_courses = Enrollment.objects.filter(student=student).values_list('course_id', flat=True)
            
            # Get completed courses (for prerequisite check)
            completed_courses = Enrollment.objects.filter(
                student=student, status='completed'
            ).values_list('course_id', flat=True)
            
            # Filter courses that the student hasn't enrolled in yet
            available_courses = Course.objects.exclude(id__in=enrolled_courses)
            
            # Further filter by checking prerequisites
            eligible_courses = []
            for course in available_courses:
                prerequisites = course.prerequisites.all()
                if not prerequisites or all(pre.id in completed_courses for pre in prerequisites):
                    eligible_courses.append(course)
            
            serializer = CourseSerializer(eligible_courses, many=True)
            return Response(serializer.data)
        except Student.DoesNotExist:
            return Response(
                {"detail": "Student profile not found for this user."},
                status=status.HTTP_404_NOT_FOUND
            )


class EnrollmentViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = EnrollmentSerializer
    
    def get_queryset(self):
        user = self.request.user
        try:
            student = user.student_profile
            return Enrollment.objects.filter(student=student)
        except Student.DoesNotExist:
            return Enrollment.objects.none()
    
    def perform_create(self, serializer):
        try:
            student = self.request.user.student_profile
            serializer.save(student=student)
        except Student.DoesNotExist:
            raise ValidationError("Student profile not found for this user.")
    
    @action(detail=False, methods=['get'])
    def current(self, request):
        try:
            student = request.user.student_profile
            current_enrollments = Enrollment.objects.filter(
                student=student,
                status='enrolled',
                semester__is_active=True
            )
            serializer = self.get_serializer(current_enrollments, many=True)
            return Response(serializer.data)
        except Student.DoesNotExist:
            return Response(
                {"detail": "Student profile not found for this user."},
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=False, methods=['get'])
    def history(self, request):
        try:
            student = request.user.student_profile
            history = Enrollment.objects.filter(student=student).order_by('-enrollment_date')
            serializer = self.get_serializer(history, many=True)
            return Response(serializer.data)
        except Student.DoesNotExist:
            return Response(
                {"detail": "Student profile not found for this user."},
                status=status.HTTP_404_NOT_FOUND
            )


class SemesterViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = SemesterSerializer
    queryset = Semester.objects.all()


class CourseCategoryViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = CourseCategorySerializer
    queryset = CourseCategory.objects.all()


# Web Views
def register_view(request):
    if request.method == 'POST':
        user_form = UserRegisterForm(request.POST)
        profile_form = StudentProfileForm(request.POST)
        
        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save()
            
            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()
            
            messages.success(request, f'Account created successfully! You can now log in.')
            return redirect('login')
    else:
        user_form = UserRegisterForm()
        profile_form = StudentProfileForm()
    
    return render(request, 'courses/register.html', {
        'user_form': user_form,
        'profile_form': profile_form,
        'title': 'Register'
    })


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f'Welcome back, {username}!')
                return redirect('dashboard')
    else:
        form = AuthenticationForm()
    
    return render(request, 'courses/login.html', {
        'form': form, 
        'title': 'Login'
    })


@login_required
def dashboard_view(request):
    try:
        student = request.user.student_profile
        
        # Get current semester enrollments
        current_enrollments = Enrollment.objects.filter(
            student=student,
            status='enrolled',
            semester__is_active=True
        )
        
        # Get counts by category
        ge_count = Enrollment.objects.filter(
            student=student,
            course__category__name='GE',
            status='completed'
        ).count()
        
        sec_count = Enrollment.objects.filter(
            student=student,
            course__category__name='SEC',
            status='completed'
        ).count()
        
        vac_count = Enrollment.objects.filter(
            student=student,
            course__category__name='VAC',
            status='completed'
        ).count()
        
        # Get recent enrollments
        recent_enrollments = Enrollment.objects.filter(
            student=student
        ).order_by('-enrollment_date')[:5]
        
        context = {
            'student': student,
            'current_enrollments': current_enrollments,
            'ge_count': ge_count,
            'sec_count': sec_count,
            'vac_count': vac_count,
            'recent_enrollments': recent_enrollments,
            'title': 'Dashboard'
        }
        
        return render(request, 'courses/dashboard.html', context)
    
    except Student.DoesNotExist:
        messages.error(request, 'Student profile not found. Please contact an administrator.')
        return redirect('login')


@login_required
def profile_view(request):
    try:
        student = request.user.student_profile
        
        if request.method == 'POST':
            profile_form = StudentProfileForm(request.POST, instance=student)
            
            if profile_form.is_valid():
                profile_form.save()
                messages.success(request, 'Your profile has been updated successfully!')
                return redirect('profile')
        else:
            profile_form = StudentProfileForm(instance=student)
        
        return render(request, 'courses/profile.html', {
            'student': student,
            'profile_form': profile_form,
            'title': 'Profile'
        })
    
    except Student.DoesNotExist:
        messages.error(request, 'Student profile not found. Please contact an administrator.')
        return redirect('dashboard')


@login_required
def course_list_view(request):
    # Get filter parameters from request
    category = request.GET.get('category', '')
    search_query = request.GET.get('search', '')
    
    # Start with all courses
    courses = Course.objects.all()
    
    # Apply filters
    if category:
        courses = courses.filter(category__name=category)
    
    if search_query:
        courses = courses.filter(
            Q(code__icontains=search_query) | 
            Q(title__icontains=search_query) |
            Q(description__icontains=search_query)
        )
    
    # Get student's enrolled courses
    try:
        student = request.user.student_profile
        enrolled_courses = Enrollment.objects.filter(student=student).values_list('course_id', flat=True)
        completed_courses = Enrollment.objects.filter(
            student=student, status='completed'
        ).values_list('course_id', flat=True)
    except Student.DoesNotExist:
        enrolled_courses = []
        completed_courses = []
    
    # Get all categories for filter dropdown
    categories = CourseCategory.objects.all()
    
    # Mark courses as enrolled, completed, or eligible
    course_data = []
    for course in courses:
        missing_prerequisites = []
        if course.id in enrolled_courses:
            status = 'enrolled'
        else:
            # Check prerequisites
            prerequisites = course.prerequisites.all()
            
            for prereq in prerequisites:
                if prereq.id not in completed_courses:
                    missing_prerequisites.append(prereq)
            
            if missing_prerequisites:
                status = 'prerequisites_missing'
            else:
                status = 'eligible'
        
        course_data.append({
            'course': course,
            'status': status,
            'missing_prerequisites': missing_prerequisites
        })
    
    return render(request, 'courses/courses_list.html', {
        'course_data': course_data,
        'categories': categories,
        'selected_category': category,
        'search_query': search_query,
        'title': 'Available Courses'
    })


@login_required
def course_detail_view(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    # Check if student is already enrolled
    try:
        student = request.user.student_profile
        is_enrolled = Enrollment.objects.filter(student=student, course=course).exists()
        
        # Check prerequisites
        completed_courses = set(
            Enrollment.objects.filter(
                student=student, status='completed'
            ).values_list('course_id', flat=True)
        )
        
        prerequisites = course.prerequisites.all()
        missing_prerequisites = []
        
        for prereq in prerequisites:
            if prereq.id not in completed_courses:
                missing_prerequisites.append(prereq)
        
        can_enroll = not is_enrolled and not missing_prerequisites
        
    except Student.DoesNotExist:
        is_enrolled = False
        missing_prerequisites = []
        can_enroll = False
    
    return render(request, 'courses/course_detail.html', {
        'course': course,
        'is_enrolled': is_enrolled,
        'missing_prerequisites': missing_prerequisites,
        'can_enroll': can_enroll,
        'title': course.title
    })


@login_required
def enrollment_history_view(request):
    try:
        student = request.user.student_profile
        
        # Get all student enrollments
        enrollments = Enrollment.objects.filter(student=student).order_by('-enrollment_date')
        
        # Group by semester
        semesters = Semester.objects.filter(
            enrollments__student=student
        ).distinct().order_by('-start_date')
        
        semester_enrollments = {}
        for semester in semesters:
            semester_enrollments[semester] = enrollments.filter(semester=semester)
        
        return render(request, 'courses/enrollment_history.html', {
            'semester_enrollments': semester_enrollments,
            'title': 'Enrollment History'
        })
    
    except Student.DoesNotExist:
        messages.error(request, 'Student profile not found. Please contact an administrator.')
        return redirect('dashboard')


@login_required
def enroll_course_view(request):
    try:
        student = request.user.student_profile
        
        if request.method == 'POST':
            form = CourseEnrollmentForm(request.POST, student=student)
            if form.is_valid():
                enrollment = form.save(commit=False)
                enrollment.student = student
                enrollment.status = 'enrolled'
                enrollment.save()
                
                messages.success(request, f'Successfully enrolled in {enrollment.course.title}!')
                return redirect('dashboard')
        else:
            form = CourseEnrollmentForm(student=student)
        
        return render(request, 'courses/enrollment_form.html', {
            'form': form,
            'title': 'Enroll in Course'
        })
    
    except Student.DoesNotExist:
        messages.error(request, 'Student profile not found. Please contact an administrator.')
        return redirect('dashboard')
