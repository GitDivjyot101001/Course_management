"""
Test script to verify our validation rules are working.
"""
from courses.models import Student, Course, Enrollment, Semester
from django.core.exceptions import ValidationError

def test_vac_duplicate_enrollment():
    """Test that a student cannot enroll in the same VAC course twice."""
    student = Student.objects.get(student_id='S003')
    tech_writing = Course.objects.get(code='VAC301')
    current_semester = Semester.objects.get(is_active=True)
    
    print(f'Attempting to enroll {student.user.username} in {tech_writing.code} (a VAC course) again...')
    
    try:
        enrollment = Enrollment(
            student=student,
            course=tech_writing,
            semester=current_semester,
            status='enrolled'
        )
        enrollment.save()
        print('Enrollment successful! This is an ERROR - should have been prevented!')
    except ValidationError as e:
        print(f'Validation Error (expected): {e}')
        print('This is correct behavior - preventing duplicate VAC enrollment.')

def test_prerequisite_validation():
    """Test that a student cannot enroll in a course without completing prerequisites."""
    student4 = Student.objects.get(student_id='S004')
    advanced_programming = Course.objects.get(code='SEC201')
    current_semester = Semester.objects.get(is_active=True)
    
    print(f'\nAttempting to enroll {student4.user.username} in {advanced_programming.code} without prerequisites...')
    
    try:
        enrollment = Enrollment(
            student=student4,
            course=advanced_programming,
            semester=current_semester,
            status='enrolled'
        )
        enrollment.save()
        print('Enrollment successful! This is an ERROR - should have been prevented!')
    except ValidationError as e:
        print(f'Validation Error (expected): {e}')
        print('This is correct behavior - preventing enrollment without prerequisites.')

if __name__ == '__main__':
    test_vac_duplicate_enrollment()
    test_prerequisite_validation()